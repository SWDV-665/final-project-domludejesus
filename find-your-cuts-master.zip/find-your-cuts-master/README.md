# find-your-cuts
This will be an Ionic App using Angular/TypeScript/SCSS and Cordova plugins

To run this app first clone this repository and do the command npm start 

then once all dependencies are installed you can use the command for ionic 

make sure you are in the location where cloned and use the command ionic serve to have this display in the browser 

There is also ios and Android cordova plugins with the google maps API which can be used using Xcode or android studio setups. 
